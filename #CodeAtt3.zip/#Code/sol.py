from os import listdir

class Book:
	def __init__(self,Id,score):
		self.Id = Id
		self.score = score

class Library:
	def __init__(self, Id, N, T, M, Books):
		self.Id = Id
		self.N = N
		self.T = T
		self.M = M
		self.Books = Books

class ChosenLib:
	def __init__(self, Id, num_books, book_ids):
		self.id = Id
		self.num_books = num_books
		self.book_ids = book_ids

def procFile(file):
	A = 0
	with open(file, "r") as fd:
		B, L, D = map(int, fd.readline().split(" "))
		Scores = list(map(int, fd.readline().split(" ")))
		Libraries = list()

		for i in range(L):
			Books = list()
			N, T, M = map(int, fd.readline().split(" "))
			Book_Nums = list(map(int, fd.readline().split(" ")))
			for b in Book_Nums:
				book = Book(b,Scores[b])
				Books.append(book)
			Books.sort(key=lambda x: x.score, reverse= True)
			Book_Nums = list()
			for x in Books:
				Book_Nums.append(x.Id)
			temp = Library(i, N, T, M, Book_Nums)
			Libraries.append(temp)

		Libraries.sort(key=lambda x: x.T)
		ChosenLibs = list()
		AllBooks = list()

		for lib in Libraries:
			D = D - lib.T
			if (D > 0):
				A = A+1
				TempBooks = list()
				books_scanned = D * lib.M
				if (books_scanned > lib.N):
					for bk in lib.Books:
						if bk not in AllBooks:
							AllBooks.append(bk)
							TempBooks.append(bk)
					lib.N = len(TempBooks)
					temp = ChosenLib(lib.Id, lib.N, TempBooks)
					ChosenLibs.append(temp)
				else:
					for  bk in lib.Books:
						if bk not in AllBooks:
							AllBooks.append(bk)
							TempBooks.append(bk)
					lib.N = len(TempBooks)
					if books_scanned > lib.N:
						temp = ChosenLib(lib.Id, lib.N, TempBooks)
					else:
						temp = ChosenLib(lib.Id, books_scanned, lib.Books[0:books_scanned])
					ChosenLibs.append(temp)

		with open(f"output/output{file}", "w") as fdo:
			fdo.write(f"{A}\n")
			for lib in ChosenLibs:
				fdo.write(f"{lib.id} {lib.num_books}\n")
				book_ids = " ".join(str(book) for book in lib.book_ids)
				fdo.write(book_ids+"\n")

for file in listdir("."):
	if file.endswith(".txt"):
		procFile(file)